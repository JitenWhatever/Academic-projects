var lbs = prompt("What is the weight in pounds (lbs)?")
var kg = lbs*0.454
alert("That is:  "+kg+" kilograms")
console.log("Conversion Completed")
